/*
 * usage: APIMicroBenchmark <host IP>
 * 
 * Connects to the host machine over TCP/IP, in order to get an external
 * time reference in a VMM-independent way. Output is logged to "output.csv".
 *
 * Micah Dowty <micah@vmware.com>
 */

using System;
using System.IO;
using System.Collections.Generic;
using System.Windows.Forms;
using System.Drawing;
using System.Net;
using System.Net.Sockets;
using System.Text;
using Microsoft.DirectX;
using Microsoft.DirectX.Direct3D;

namespace APIMicroBench
{
    struct TestParams
    {
        public int numTriangles;
        public int numDraws;
        public bool fill;
        public bool dynamic;
    }

    class TestRun
    {
        Device device;
        VertexBuffer vertexBuffer;
        CustomVertex.PositionOnly[] vertices;
        CustomVertex.PositionOnly[] altVertices;
        Effect effect;
        EffectHandle paramHandle;
        TestParams testParams;
        Boolean colorToggle;

        public void Init(Device device, TestParams testParams)
        {
            this.device = device;
            this.testParams = testParams;

            vertices = new CustomVertex.PositionOnly[testParams.numTriangles * 3];
            altVertices = new CustomVertex.PositionOnly[testParams.numTriangles * 3];

            int triangle;
            int offset = 0;

            for (triangle = 0; triangle < testParams.numTriangles; triangle++) {
                if (testParams.fill)
                {
                    const float size = 1.0f;

                    vertices[offset].X = -size;
                    vertices[offset].Y = -size;
                    offset++;

                    vertices[offset].X = 0.0f;
                    vertices[offset].Y = size;
                    offset++;

                    vertices[offset].X = size;
                    vertices[offset].Y = -size;
                    offset++;
                }
                else
                {
                    vertices[offset].X = 0;
                    vertices[offset].Y = 0;
                    offset++;

                    vertices[offset].X = 0;
                    vertices[offset].Y = 0;
                    offset++;

                    vertices[offset].X = 0;
                    vertices[offset].Y = 0;
                    offset++;
                }
            }

            for (offset = 0; offset < altVertices.Length; offset++)
            {
                altVertices[offset].X = 0.1f;
                altVertices[offset].Y = 0.1f;
            }

            if (vertexBuffer != null)
            {
                vertexBuffer.Dispose();
            }
            vertexBuffer = new VertexBuffer(typeof(CustomVertex.PositionOnly),
                                            vertices.Length, device, Usage.None,
                                            CustomVertex.PositionOnly.Format,
                                            testParams.dynamic ? Pool.Default : Pool.Managed);
            vertexBuffer.SetData(vertices, 0, LockFlags.Discard);

            String effectData = @"
                struct VSInput
                {
	                float4 Position : POSITION;
                };

                struct VSOutput
                {
	                float4 Position : POSITION;
                };

                uniform float Param;
                
                VSOutput vs_main(VSInput input)
                {
	                VSOutput output;
	                output.Position.x = input.Position.x + Param;
                    output.Position.y = input.Position.y;
                    output.Position.z = 1.0;
                    output.Position.w = 1.0;
                    return output;
                };

                float4 ps_main(VSOutput input) : COLOR
                {
	                return float4(0.0, 0.0, 0.0, 1.0);
                };

                technique Main
                {
	                pass P0
	                {
		                VertexShader = compile vs_1_1 vs_main();

                        // XXX: Don't use a pixel shader. Fusion seems to be triggering
                        // a Mac OS bug when we use this trivial shader, causing this to
                        // be about 10x slower than it should be.

		                //PixelShader = compile ps_1_0 ps_main();
	                }
                }
            ";
            String compilationErrors;
            effect = Effect.FromString(device, effectData, null, "", ShaderFlags.None, new EffectPool(), out compilationErrors);
            if (effect == null)
            {
                MessageBox.Show(compilationErrors);
            }
            else
            {
                paramHandle = effect.GetParameter(null, "Param");
            }
        }

        public void Render()
        {
            Boolean bufferToggle = false;
            
            // Toggle the clear color, as a visual indicator to show when a new frame is rendered.
            colorToggle = !colorToggle;
            device.Clear(ClearFlags.Target | ClearFlags.ZBuffer,
                colorToggle ? Color.SkyBlue : Color.CornflowerBlue, 1.0f, 0);

            device.BeginScene();

            device.SetStreamSource(0, vertexBuffer, 0);
            device.VertexFormat = CustomVertex.PositionOnly.Format;

            if (effect != null) {
                for (int draw = 0; draw < testParams.numDraws; draw++)
                {
                    // Introduce a non-optimizable state change before each draw, so
                    // all drivers must perform at least minimal reconfiguration between
                    // draws. This is much more realistic than drawing many primitive sets
                    // using exactly the same shader state.
                    effect.SetValue(paramHandle, colorToggle ? 1.0f : 0.0f);

                    if (testParams.dynamic) {
                        bufferToggle = !bufferToggle;
                        vertexBuffer.SetData(bufferToggle ? altVertices : vertices, 0, LockFlags.Discard);
                    }

                    int numPasses = effect.Begin(0);
                    for (int pass = 0; pass < numPasses; pass++)
                    {
                        effect.BeginPass(pass);
                        device.DrawPrimitives(PrimitiveType.TriangleList, 0, testParams.numTriangles);
                        effect.EndPass();
                    }
                    effect.End();
                }
            }
            
            device.EndScene();
            device.Present();
        }

        double GetHostTime()
        {
            TcpClient client = new TcpClient();
            client.Connect(Environment.GetCommandLineArgs()[1], 12345);
            Stream s = client.GetStream();
            Byte[] buffer = new Byte[128];

            s.Read(buffer, 0, buffer.Length);
            String str = Encoding.ASCII.GetString(buffer);
            return double.Parse(str);
        }

        public double Run()
        {
            // Note that we must design the test such that each individual frame takes long
            // enough to render that vsync and other Present-time effects are negligible.
            //
            // These numbers must be even, so there is no bias introduced by effects that we toggle
            // every other frame.

            const int warmupFrames = 2;
            const int measureFrames = 4;
            int i;

            Application.DoEvents();

            for (i = 0; i < warmupFrames; i++) {
                Render();
            }

            double startTime = GetHostTime();
            for (i = 0; i < measureFrames; i++) {
                Render();
                Application.DoEvents();
            }
            double stopTime = GetHostTime();
            
            return stopTime - startTime;
        }
    }

    class MainWindow : Form
    {
        public Device device;
        StreamWriter logFile;
        
        public void Init()
        {
            logFile = new StreamWriter("output.csv");

            this.ClientSize = new System.Drawing.Size(320, 240);
            this.Text = "API Microbenchmarks";

            PresentParameters presentParams = new PresentParameters();

            presentParams.Windowed = true;
            presentParams.PresentationInterval = PresentInterval.Immediate;
            presentParams.SwapEffect = SwapEffect.Discard;
            presentParams.EnableAutoDepthStencil = true;
            presentParams.AutoDepthStencilFormat = DepthFormat.D16;

            device = new Device(0, DeviceType.Hardware, this,
                                CreateFlags.HardwareVertexProcessing | CreateFlags.PureDevice,
                                presentParams);
        }

        void BeginTest(string name)
        {
            Console.WriteLine(name);
            logFile.WriteLine();
            logFile.WriteLine("Test: {0}", name);
            logFile.WriteLine();
        }

        void LogPair(object a, object b)
        {
            logFile.WriteLine("{0},{1}", a, b);
            logFile.Flush();
            Console.WriteLine("{0},{1}", a, b);
        }

        public void RunTests()
        {
            TestRun test = new TestRun();
            TestParams p;
            const int numSteps = 100;
            int maxValue, stepSize;

            p.dynamic = false;
            p.fill = false;

#if true
            BeginTest("Dynamic triangle throughput");
            LogPair("numTriangles", "time");

            p.dynamic = true;
            p.numDraws = 50;
            maxValue = 100000;
            stepSize = maxValue / numSteps;
            for (p.numTriangles = stepSize; p.numTriangles <= maxValue; p.numTriangles += stepSize) {
                test.Init(device, p);
                LogPair(p.numTriangles, test.Run());
            }
            p.dynamic = false;
#endif

#if true
            BeginTest("Static triangle throughput");
            LogPair("numTriangles", "time");

            p.numDraws = 1000;
            maxValue = 100000;
            stepSize = maxValue / numSteps;
            for (p.numTriangles = stepSize; p.numTriangles <= maxValue; p.numTriangles += stepSize)
            {
                test.Init(device, p);
                LogPair(p.numTriangles, test.Run());
            }
#endif

#if true
            BeginTest("Draw call overhead");
            LogPair("numDraws", "time");

            p.numTriangles = 10;
            maxValue = 50000;
            stepSize = maxValue / numSteps;
            for (p.numDraws = stepSize; p.numDraws <= maxValue; p.numDraws += stepSize)
            {
                test.Init(device, p);
                LogPair(p.numDraws, test.Run());
            }
#endif

#if true
            BeginTest("Filled triangle throughput");
            LogPair("numTriangles", "time");

            p.fill = true;
            p.numDraws = 150;
            maxValue = 1000;
            stepSize = maxValue / numSteps;
            for (p.numTriangles = stepSize; p.numTriangles <= maxValue; p.numTriangles += stepSize) {
                test.Init(device, p);
                LogPair(p.numTriangles, test.Run());
            }
            p.fill = false;
#endif
        }
    
    }

    static class Program
    {
        static void Main()
        {
            Application.EnableVisualStyles();
            MainWindow form = new MainWindow();
 
            form.Init();
            form.Show();

            form.RunTests();
            form.device.Dispose();
        }
    }
}