#!/usr/bin/env python

PORT = 12345

import socket
import time

sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
sock.bind(("", PORT))
sock.listen(1)

while True:
    conn, peer = sock.accept()
    conn.setsockopt(socket.SOL_TCP, socket.TCP_NODELAY, 1)
    conn.send("%.6f\0" % time.time())
    conn.close()
